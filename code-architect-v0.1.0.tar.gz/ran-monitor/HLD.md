# 5G RAN Monitor Skill — 高层设计文档 (HLD)

## 1. 概述

### 1.1 Skill 定位
**ran-monitor** 是一个面向 5G RAN / Open RAN 场景的 OpenClaw Skill。它让 AI Agent 能够：
- 采集 RAN 设备/模拟器的 KPI 和日志
- 诊断网络异常（掉话、拥塞、覆盖盲区）
- 生成 RAN 运维日报/战报
- 对接 O-RAN RIC 的 xApp/rApp 生态

### 1.2 设计原则
- **开放对接**：支持 OAI、srsRAN、UERANSIM、O-RAN SC 等主流开源 RAN
- **云原生友好**：K8s 部署的 vRAN 也能直接采集
- **AI 原生内建**：异常检测不是外挂，是 skill 的核心能力
- **可扩展**：模块化架构，新增一种 RAN 类型只需加一个 Adapter

---

## 2. 目标架构 vs 现状

### 2.1 目标架构（重构后）

```
┌─────────────────────────────────────────────────────────────┐
│                    OpenClaw Agent Layer                       │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐ │
│  │ 自然语言指令 │  │ 异常告警响应 │  │ 日报/战报生成        │ │
│  │ "检查小区负载" │  │ "触发自动扩容" │  │ "输出今日RAN战报"   │ │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘ │
└─────────┼──────────────────┼─────────────────────┼───────────┘
          │                  │                     │
          ▼                  ▼                     ▼
┌─────────────────────────────────────────────────────────────┐
│                   ran-monitor Skill Core                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │   Parser     │  │   Analyzer   │  │   Reporter   │     │
│  │  (日志解析)    │  │  (异常诊断)   │  │  (报告生成)   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │   Collector  │  │   Detector   │  │   Action     │     │
│  │  (指标采集)    │  │  (AI检测)    │  │  (自动动作)   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└─────────────────────────────────────────────────────────────┘
          │                  │                     │
          ▼                  ▼                     ▼
┌─────────────────────────────────────────────────────────────┐
│                    RAN Adapter Layer                          │
│  ┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐           │
│  │ OAI    │  │ srsRAN │  │UERANSIM│  │O-RAN SC│  ...       │
│  │ Adapter│  │ Adapter│  │ Adapter│  │ Adapter│            │
│  └────┬───┘  └────┬───┘  └────┬───┘  └────┬───┘            │
└───────┼───────────┼───────────┼───────────┼────────────────┘
        │           │           │           │
   ┌────┴───┐  ┌───┴────┐ ┌───┴────┐ ┌───┴────┐
   │ OAI gNB│  │srsRAN  │ │UERANSIM│ │RIC     │
   │ Logs   │  │Metrics │ │Emulator│ │xApp/rApp│
   └────────┘  └────────┘ └────────┘ └────────┘
```

### 2.2 现状问题（假设用户现有代码）

如果用户当前是零散脚本状态，常见痛点：

| 痛点 | 现状 | 重构后 |
|------|------|--------|
| 对接方式 | 每个 RAN 一套独立脚本，重复代码多 | 统一 Adapter 层，新增 RAN 只需填 Adapter |
| 数据处理 | 原始日志直接输出，无结构化 | Parser → 标准化 Schema → Analyzer |
| 异常检测 | 人工看日志 grep | AI Detector 自动识别模式异常 |
| 报告生成 | 手动复制粘贴 | Reporter 自动生成 Markdown/PDF 战报 |
| 自动化 | 没有闭环，检测后手动处理 | Action 模块触发自动调优/告警 |

---

## 3. 模块划分 (Module Breakdown)

### 3.1 Core Modules

| 模块 | 职责 | 关键类/函数 | 输出 |
|------|------|-------------|------|
| **Collector** | 从 RAN 源采集原始数据 | `collect_logs()`, `collect_metrics()` | Raw JSON / Log Stream |
| **Parser** | 解析原始数据为标准格式 | `parse_oai_log()`, `parse_srsran_metric()` | Standard KPI Schema |
| **Analyzer** | 业务逻辑分析（负载、时延、掉话率） | `analyze_cell_load()`, `analyze_latency()` | Analysis Report |
| **Detector** | AI 异常检测 | `detect_anomaly()`, `predict_failure()` | Alert / Confidence Score |
| **Reporter** | 报告生成 | `generate_daily_report()`, `generate_alert_card()` | Markdown / PDF / Interactive Card |
| **Action** | 自动执行 | `trigger_scaling()`, `send_alert()` | API Call / Config Update |

### 3.2 Adapter Layer

| Adapter | 对接目标 | 数据源 | 协议 |
|-----------|---------|--------|------|
| `OAIAdapter` | OpenAirInterface gNB/UE | Log files, stdout | File tail / UDP |
| `SrsRANAdapter` | srsRAN 4G/5G | JSON metrics | ZMQ / File |
| `UERANSIMAdapter` | UERANSIM emulator | Console / API | gRPC / REST |
| `ORANRICAdapter` | O-RAN SC Near-RT RIC | E2AP / A1/P1 | gRPC / REST |
| `PrometheusAdapter` | 通用云原生监控 | Metrics endpoint | HTTP / PromQL |

---

## 4. 数据流设计 (Data Flow)

```
┌─────────────┐     ┌─────────────┐     ┌─────────────────┐
│  RAN Source │────▶│  Collector  │────▶│  Raw Data Buffer │
│ (Log/Metric)│     │ (Pull/Push) │     │  (File/Redis)    │
└─────────────┘     └─────────────┘     └────────┬────────┘
                                                  │
┌─────────────────────────────────────────────────┘
│
▼
┌─────────────┐     ┌─────────────┐     ┌─────────────────┐
│   Parser    │────▶│  KPI Schema │────▶│  Time-Series DB  │
│(Regex/JSON) │     │ (Standard)  │     │  (Influx/Prom)   │
└─────────────┘     └─────────────┘     └────────┬────────┘
                                                  │
                    ┌───────────────────────────────┘
                    │
                    ▼
        ┌─────────────────────────────────────────┐
        │           Analysis Pipeline              │
        │  ┌─────────┐  ┌─────────┐  ┌─────────┐ │
        │  │ Analyzer│  │ Detector│  │ Action  │ │
        │  │(规则)   │  │(AI模型) │  │(执行)   │ │
        │  └────┬────┘  └────┬────┘  └────┬────┘ │
        └───────┼────────────┼────────────┼──────┘
                │            │            │
                ▼            ▼            ▼
        ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
        │ 统计报表    │ │ 异常告警     │ │ 自动修复/通知 │
        └─────────────┘ └─────────────┘ └─────────────┘
```

### 4.1 KPI Schema 标准格式

```json
{
  "timestamp": "2026-05-13T11:30:00Z",
  "source": "oai_gnb_01",
  "cell_id": "cell_001",
  "metrics": {
    "dl_throughput_mbps": 145.2,
    "ul_throughput_mbps": 32.1,
    "active_ues": 124,
    "handover_success_rate": 0.987,
    "rssi_dbm": -78.5,
    "latency_ms": 12.3
  },
  "anomaly_score": 0.15,
  "tags": ["urban", "hotspot"]
}
```

---

## 5. 接口设计 (Interfaces)

### 5.1 Skill 对外接口（用户自然语言触发）

```markdown
用户: "采集 OAI gNB 的当前指标"
Skill: Collector → OAIAdapter → 返回实时 KPI 面板

用户: "检测过去1小时是否有异常"
Skill: Collector → Parser → Analyzer → Detector → 返回异常列表

用户: "生成今日 RAN 战报"
Skill: Reporter → 输出 Markdown/PDF 日报

用户: "如果小区负载超过80%自动告警"
Skill: 配置 Action 规则 → 持续监控 → 触发告警
```

### 5.2 内部模块接口

```python
# Collector → Parser
def collect(source: RANSource, interval: int) -> RawDataStream:
    """采集原始数据"""

# Parser → Analyzer
def parse(raw: RawDataStream, adapter: Adapter) -> List[KPIRecord]:
    """解析为标准 KPI"""

# Analyzer → Detector
def analyze(kpis: List[KPIRecord], rules: RuleSet) -> AnalysisResult:
    """规则分析"""

def detect(kpis: List[KPIRecord], model: AIModel) -> List[Anomaly]:
    """AI 异常检测"""

# Reporter 输出
def generate_report(data: AnalysisResult, template: ReportTemplate) -> str:
    """生成报告"""
```

---

## 6. AI 异常检测设计

### 6.1 检测维度

| 维度 | 指标 | 检测方法 |
|------|------|----------|
| **负载异常** | 用户数、吞吐量、PRB 利用率 | 阈值 + 时间序列预测 (Prophet/ARIMA) |
| **质量劣化** | 掉话率、切换失败率、RSSI | 统计异常检测 (Z-Score/Isolation Forest) |
| **时延抖动** | RTT、处理时延 | 模式匹配 + 趋势分析 |
| **能效异常** | 功耗 vs 负载不匹配 | 回归模型偏差检测 |

### 6.2 模型部署方式

```
轻量级（默认）: 规则引擎 + 统计检测
    ↓ 可选升级
中量级: scikit-learn (Isolation Forest, LOF)
    ↓ 可选升级
重量级: 本地 LLM / 远程 API 做根因分析 (RCA)
```

---

## 7. 部署与集成

### 7.1 部署模式

| 模式 | 场景 | 架构 |
|------|------|------|
| **单机模式** | 开发测试、单站监控 | Skill 直连本地 RAN 日志/进程 |
| **K8s 模式** | 生产 vRAN / Cloud RAN | Skill 通过 Prometheus / Sidecar 采集 |
| **RIC 模式** | O-RAN 生态 | Skill 作为 E2 Node 或 xApp 接入 Near-RT RIC |

### 7.2 与 OpenClaw 生态集成

```
ran-monitor Skill
    ├── 调用 web-fetch / browser → 采集 Web GUI 数据
    ├── 调用 github Skill → 管理 RAN 代码版本/配置
    ├── 调用 daily-report Skill → 生成 RAN 日报
    └── 调用 message → 发送告警到飞书/钉钉/微信
```

---

## 8. 重构路径建议

如果用户现有代码是零散采集脚本，建议按以下步骤重构：

```
Phase 1: 统一 Parser（1周）
    - 将各种 RAN 的日志解析提取为 Adapter 模块
    - 输出统一 KPI Schema

Phase 2: 搭建 Analyzer + Reporter（1周）
    - 规则分析引擎
    - Markdown/PDF 报告模板

Phase 3: 引入 AI Detector（2周）
    - 接入 scikit-learn / 本地小模型
    - 异常检测 + 根因分析

Phase 4: 闭环 Action（1周）
    - 告警通知
    - 自动扩缩容触发

Phase 5: RIC 对接（可选，2周）
    - 实现 E2AP 接口
    - 作为 xApp 部署到 Near-RT RIC
```

---

## 9. 技术栈建议

| 层级 | 技术 |
|------|------|
| 采集 | Python + asyncio / file-tail / requests |
| 解析 | regex + pydantic (schema validation) |
| 存储 | InfluxDB (时序) / SQLite (本地轻量) |
| 分析 | pandas + scikit-learn / statsmodels |
| AI | 轻量: 规则引擎; 中量: sklearn; 重量: local LLM |
| 报告 | Markdown + jinja2 / weasyprint (PDF) |
| 部署 | Docker / Helm (K8s) / OpenClaw native |

---

## 10. 产出物清单

完成 HLD 后，下一步 DLD 需要细化：

- [ ] `SKILL.md` — OpenClaw 标准 Skill 文档
- [ ] `adapter/` — 各 RAN 适配器实现
- [ ] `core/` — Collector/Parser/Analyzer/Detector/Reporter/Action
- [ ] `models/` — 异常检测模型（规则 + ML）
- [ ] `templates/` — 报告模板（日报/告警/战报）
- [ ] `tests/` — 单元测试 + 集成测试
- [ ] `config.yaml` — 配置文件示例

---

*文档版本: v1.0*
*适用: 5G RAN / Open RAN 监控类 Skill 的 HLD 阶段*
*下一步: 基于本 HLD 输出 DLD（详细设计）或直接启动 SKILL.md 编写*
