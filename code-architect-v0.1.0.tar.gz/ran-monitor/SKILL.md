---
name: ran-monitor
description: >
  面向 5G RAN / Open RAN 场景的智能监控与运维 Skill。
  支持对接 OAI、srsRAN、UERANSIM、O-RAN SC 等主流开源 RAN，
  实现 KPI 采集、AI 异常检测、自动诊断、日报/战报生成及告警闭环。
  适用于云原生 vRAN、容器化部署及 O-RAN RIC xApp/rApp 生态。
---

# RAN Monitor Skill

## 概述

ran-monitor 是一个面向 5G RAN / Open RAN 的 OpenClaw Skill，让 AI Agent 能够直接对话无线接入网——采集指标、诊断异常、生成报告、触发自动修复。

### 核心能力

- **多源采集**：对接 OAI、srsRAN、UERANSIM、O-RAN SC Near-RT RIC、Prometheus
- **统一建模**：将各厂商/模拟器的异构日志解析为标准 KPI Schema
- **AI 诊断**：内置异常检测（统计规则 + ML + 可选 LLM 根因分析）
- **报告生成**：自动输出 Markdown / PDF 运维日报、告警卡片
- **闭环动作**：检测 → 诊断 → 告警 / 自动扩缩容 / 通知飞书/钉钉

### 设计原则

- **开放对接**：新增一种 RAN 类型只需实现一个 Adapter
- **云原生友好**：支持 K8s 部署的 vRAN（Prometheus / Sidecar 模式）
- **AI 原生内建**：异常检测是核心能力，非外挂脚本
- **可扩展**：从单机脚本到 RIC xApp，同一套代码逐步演进

---

## 使用场景

### 场景 1：实时指标查看

用户："采集 OAI gNB 的当前指标"

Agent：
1. 调用 `Collector` 通过 `OAIAdapter` 读取日志/metrics
2. `Parser` 解析为标准 KPI
3. 输出实时面板：小区负载、吞吐、连接数、时延

### 场景 2：异常检测

用户："检测过去 1 小时是否有异常"

Agent：
1. 采集最近 1 小时 KPI 数据
2. `Analyzer` 规则分析（掉话率、负载阈值）
3. `Detector` AI 检测（Isolation Forest / 时序预测）
4. 输出异常列表 + 置信度 + 根因建议

### 场景 3：日报生成

用户："生成今日 RAN 战报"

Agent：
1. 汇总 24h KPI 数据
2. 统计峰值/均值/异常事件
3. `Reporter` 生成 Markdown / PDF 日报
4. 可选：调用 `daily-report` Skill 发送飞书/微信

### 场景 4：自动告警

用户："如果小区负载超过 80% 自动告警"

Agent：
1. 配置 `Action` 规则（阈值 + 条件）
2. 持续监控（可配合 cron 定时任务）
3. 触发时：发送告警卡片 + 自动通知 + 记录日志

### 场景 5：RIC 对接（高级）

用户："作为 xApp 接入 O-RAN RIC，监控 E2 节点"

Agent：
1. 启动 `ORANRICAdapter`
2. 通过 E2AP 订阅 RAN 功能（如 UE 关联、负载上报）
3. 实时接收 E2 指示消息，做近实时异常检测

---

## 架构

```
OpenClaw Agent
       │
       ▼
┌─────────────────────────┐
│   ran-monitor Core      │
│  ┌─────────┐           │
│  │Collector│──┐         │
│  └────┬────┘  │         │
│  ┌────▼────┐  │         │
│  │ Parser  │  │         │
│  └────┬────┘  │         │
│  ┌────▼────┐  │         │
│  │Analyzer │  │         │
│  └────┬────┘  │         │
│  ┌────▼────┐  │         │
│  │Detector │──┼── AI    │
│  └────┬────┘  │         │
│  ┌────▼────┐  │         │
│  │Reporter │◀─┘         │
│  └────┬────┘            │
│  ┌────▼────┐            │
│  │ Action  │── 告警/修复 │
│  └─────────┘            │
└─────────────────────────┘
       │
       ▼
┌─────────────────────────┐
│      Adapter Layer        │
│ OAI │ srsRAN │ UERANSIM  │
│ O-RAN SC │ Prometheus    │
└─────────────────────────┘
```

---

## 工具集

本 Skill 通过以下工具/命令与 RAN 系统交互：

### 1. 文件/日志采集

```bash
# 读取 OAI gNB 日志（本地文件）
tail -f /tmp/openairinterface/gnb.log | grep "RRC_CONNECTED"

# 读取 srsRAN metrics JSON
python3 -c "import zmq; ..."  # 或读取本地 metrics.json
```

### 2. HTTP / REST / gRPC 采集

```bash
# Prometheus 查询
curl -s "http://localhost:9090/api/v1/query?query=ran_cell_load"

# O-RAN SC RIC A1/E2 接口（通过 Python gRPC 客户端）
python3 scripts/oran_ric_client.py --ric-host <host> --action subscribe
```

### 3. 数据处理（Python）

```python
# 解析 OAI 日志为正则结构化数据
import re
def parse_oai_log(line: str) -> dict:
    pattern = r".*RRC\[(\d+)\].*UE_id=(\d+).*"
    m = re.match(pattern, line)
    return {"ue_id": m.group(2), "cell_id": m.group(1)} if m else None
```

### 4. AI 检测（Python）

```python
# 轻量级：统计规则
# 中量级：scikit-learn
from sklearn.ensemble import IsolationForest

def detect_anomaly(kpi_vectors: list) -> list:
    clf = IsolationForest(contamination=0.05)
    preds = clf.fit_predict(kpi_vectors)
    return [i for i, p in enumerate(preds) if p == -1]
```

### 5. 报告生成

```python
# Markdown 日报
import jinja2

def generate_daily_report(kpis: list, anomalies: list) -> str:
    template = jinja2.Template(open("templates/daily.md.j2").read())
    return template.render(kpis=kpis, anomalies=anomalies)
```

---

## 配置

### 环境变量

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `RAN_TYPE` | 对接的 RAN 类型：`oai` / `srsran` / `ueransim` / `oran_ric` / `prometheus` | `oai` |
| `RAN_LOG_PATH` | OAI/srsRAN 日志路径 | `/tmp/openairinterface/gnb.log` |
| `RAN_METRICS_PORT` | Prometheus / srsRAN metrics 端口 | `9090` |
| `RIC_HOST` | O-RAN RIC 地址 | `localhost` |
| `RIC_PORT` | O-RAN RIC gRPC 端口 | `50051` |
| `INFLUX_URL` | InfluxDB 时序库地址（可选） | `http://localhost:8086` |
| `ALERT_WEBHOOK` | 告警通知 Webhook（飞书/钉钉/企业微信） | 空 |

### 配置文件（config.yaml）

```yaml
ran:
  type: oai
  log_path: /tmp/openairinterface/gnb.log
  metrics_endpoint: http://localhost:9090/metrics

analysis:
  interval_seconds: 60
  anomaly_threshold: 0.8
  ai_model: light  # light / medium / heavy

report:
  daily_template: templates/daily.md.j2
  output_dir: ./reports/

alert:
  webhook: "https://open.feishu.cn/open-apis/bot/v2/hook/xxxx"
  rules:
    - name: "cell_overload"
      metric: "cell_load"
      condition: "> 80"
      cooldown_minutes: 10
```

---

## 安装

```bash
# 从 GitHub 安装
openclaw skill install https://github.com/<your-org>/ran-monitor

# 或手动复制到 workspace
mkdir -p ~/.openclaw/skills/ran-monitor
cp -r . ~/.openclaw/skills/ran-monitor/
```

### 依赖

```bash
pip install -r requirements.txt
```

核心依赖：
- `pandas`, `numpy` — 数据处理
- `pydantic` — Schema 校验
- `jinja2` — 报告模板
- `requests`, `aiohttp` — HTTP 采集
- `scikit-learn` — AI 检测（可选，medium 模式）
- `influxdb-client` — 时序存储（可选）

---

## 开发扩展

### 新增 RAN Adapter

1. 在 `adapters/` 下新建 `your_ran.py`
2. 实现 `YourRANAdapter(BaseAdapter)` 接口：
   - `connect()` — 建立连接
   - `collect()` — 采集原始数据
   - `disconnect()` — 断开连接
3. 在 `config.yaml` 中注册 `ran.type: your_ran`

### 新增检测维度

1. 在 `detectors/` 下新建检测器，继承 `BaseDetector`
2. 实现 `detect(kpi_records: list[KPIRecord]) -> list[Anomaly]`
3. 在 `analysis.ai_model` 中注册

---

## 注意事项

- **实时性**：AI 异常检测（medium/heavy 模式）可能引入秒级延迟，生产环境建议先启用 light 规则引擎
- **安全**：RIC 对接涉及 E2AP/E1 接口，确保网络隔离和证书配置正确
- **资源**：heavy 模式（LLM 根因分析）需要 GPU 或远程 API Key，建议在非实时场景使用
- **兼容性**：O-RAN SC 版本迭代较快，Adapter 需适配具体 RIC 版本

---

## 相关链接

- OpenAirInterface: https://openairinterface.org/
- srsRAN: https://www.srsran.com/
- UERANSIM: https://github.com/aligungr/UERANSIM
- O-RAN SC: https://github.com/o-ran-sc/
- Open RAN Gym: https://openrangym.com/

---

*Skill 版本: v0.1.0*
*适用 OpenClaw 版本: ≥ 2025.x*
*作者: fenfang.tian + kimi claw*
*维护: 通信 RAN 领域技能持续迭代中*
