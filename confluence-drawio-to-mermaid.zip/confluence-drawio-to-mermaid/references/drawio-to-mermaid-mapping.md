# Draw.io to Mermaid Mapping Reference

## Supported Input Formats

### Local Files

1. **Standalone `.drawio` / `.xml`** — Raw `mxGraphModel` XML
2. **Confluence HTML export** — Draw.io macros in exported HTML
3. **Confluence storage format (XHTML)** — `ac:structured-macro` with `ac:rich-text-body`
4. **JSON-embedded** — `diagram data-diagram-data` attributes or JSON files with `"xml"` field
5. **`<draw-io>`** tagged content

### Remote URLs (Confluence Pages)

6. **Confluence page URL + Cookie** — Scrapes the rendered page HTML (recommended for Server/DC with 498 errors)
7. **Confluence page URL + PAT** — Uses Bearer auth against `/rest/api/content/{id}?expand=body.storage`
8. **Confluence page URL + Username/Password** — Uses Basic auth
9. **Public pages** — No authentication required

## Diagram Type Auto-Detection

| Heuristic | Diagram Type |
|-----------|-------------|
| `swimlane` count >= 2 | `sequenceDiagram` |
| `lifeline` in node styles | `sequenceDiagram` |
| `activation` in node styles | `sequenceDiagram` |
| `umlClass`, `class;`, `interface;` in styles | `classDiagram` |
| `state;`, `endState`, `startState` in styles | `stateDiagram` |
| Default fallback | `flowchart` |

Override with `--type flowchart|sequence|class`.

## Shape Mapping (Flowchart)

| Draw.io Style | Mermaid Syntax | Notes |
|--------------|----------------|-------|
| `ellipse`, `circle`, `oval`, `start`, `end` | `(("Label"))` | Terminal nodes |
| `rhombus`, `diamond` | `{{"Label"}}` | Decision nodes |
| `rounded` / `rounded=1` | `("Label")` | Rounded rectangle |
| `parallelogram` | `[/"Label" /]` | Input/output |
| `cylinder`, `cylinder3` | `[("Label")]` | Database |
| `hexagon` | `{{{{"Label"}}}}` | Hexagon |
| `double` / `doubleEllipse` | `[["Label"]]` | Subroutine |
| Default / rectangle | `["Label"]` | Process |

## Edge Mapping (Flowchart)

| Draw.io Style | Mermaid Arrow |
|--------------|---------------|
| `dashed=1` | `.->` |
| `endArrow=none` / `startArrow=none` | `--` |
| `endArrow=block` + no fill | `-->` |
| Default | `-->` |

## Edge Mapping (Class Diagram)

| Draw.io Style | Mermaid Relation |
|--------------|------------------|
| `startArrow=diamond` + `endArrow=block` | `*--` (Composition) |
| `endArrow=block` + `startArrow=none` | `--|>` (Inheritance) |
| `endArrow=open` | `-->` (Association) |

## Authentication Notes for Confluence URLs

### Confluence Server / Data Center (自建域名)

- **498 errors with PAT**: Server/DC sometimes rejects Bearer tokens on `/rest/api/content`. Use `--cookie` instead.
- **Cookie extraction**: Log in via browser → F12 → Application/Storage → Cookies → copy `JSESSIONID` or full cookie string.
- **Basic Auth**: Some Server instances accept `--username` + `--password` (where password is the API token).

### Confluence Cloud (`xxx.atlassian.net`)

- Use `--email` + `--token` (API token from id.atlassian.com) with Basic Auth.
- Cloud does not typically return 498; 401/403 means the token lacks page read permission.

## Known Limitations

1. **Complex layouts** — Mermaid auto-layouts; manual positioning from draw.io is lost.
2. **Custom shapes** — Non-standard draw.io shapes fall back to rectangles.
3. **Nested groups** — Only one-level subgraphs are generated.
4. **State diagrams** — Auto-detected but use basic `classDiagram` generator; state-specific syntax (states, transitions) may need manual refinement.
5. **Images/icons** — Embedded images are ignored.
6. **Edge routing** — Orthogonal/polygonal edge routes are simplified to direct arrows.
7. **Multiline text** — `<br>` is converted to Mermaid `<br/>`; actual newlines are preserved.
8. **JavaScript-rendered diagrams** — If the page loads diagram data via XHR after page load, the static HTML scrape may miss it. In that case, use the browser Network tab to find the XHR response and save it locally.
