#!/usr/bin/env python3
"""
Convert draw.io XML (from Confluence or standalone) to Mermaid format.
Supports: flowcharts, sequence diagrams, and basic class diagrams.
Supports local files, Confluence REST API, and direct page HTML scraping.
"""

import xml.etree.ElementTree as ET
import re
import sys
import html
import argparse
import json
import urllib.request
import urllib.parse
import urllib.error
import base64


# ---------------------------------------------------------------------------
# HTTP / Authentication helpers
# ---------------------------------------------------------------------------

def fetch_url(url, cookie=None, username=None, password=None, pat=None):
    """
    Fetch content from a URL with optional authentication.

    Auth precedence: cookie > pat (Bearer) > basic auth (username+password)
    """
    req = urllib.request.Request(url)

    if cookie:
        req.add_header('Cookie', cookie)
    elif pat:
        # Confluence Server/DC Personal Access Token via Bearer
        req.add_header('Authorization', f'Bearer {pat}')
    elif username and password:
        # Basic Auth (Cloud API tokens, or Server fallback)
        creds = base64.b64encode(f'{username}:{password}'.encode()).decode()
        req.add_header('Authorization', f'Basic {creds}')

    req.add_header('User-Agent', 'confluence-drawio-to-mermaid/1.0')

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            charset = resp.headers.get_content_charset('utf-8')
            return resp.read().decode(charset)
    except urllib.error.HTTPError as e:
        raise RuntimeError(f'HTTP {e.code} {e.reason} for URL: {url}') from e
    except urllib.error.URLError as e:
        raise RuntimeError(f'Network error: {e.reason} for URL: {url}') from e


def extract_page_id_from_url(url):
    """Attempt to extract a Confluence page ID from common URL patterns."""
    # Pattern 1: /pages/viewpage.action?pageId=12345
    m = re.search(r'[?&]pageId=(\d+)', url)
    if m:
        return m.group(1)
    # Pattern 2: /pages/12345/ or /wiki/spaces/.../pages/12345/
    m = re.search(r'/pages/(\d+)(?:/|$)', url)
    if m:
        return m.group(1)
    # Pattern 3: /wiki/rest/api/content/12345
    m = re.search(r'/content/(\d+)(?:\?|$)', url)
    if m:
        return m.group(1)
    return None


def build_api_base_from_url(url):
    """Derive the REST API base URL from a Confluence page URL."""
    parsed = urllib.parse.urlparse(url)
    # Try to find the context path (e.g., /confluence or /wiki)
    path = parsed.path
    # Common context paths
    for ctx in ['/wiki', '/confluence', '/display', '/pages']:
        idx = path.find(ctx)
        if idx != -1:
            base = f'{parsed.scheme}://{parsed.netloc}{path[:idx]}{ctx}'
            return f'{base}/rest/api'
    # Default fallback
    return f'{parsed.scheme}://{parsed.netloc}/rest/api'


# ---------------------------------------------------------------------------
# Content extraction helpers
# ---------------------------------------------------------------------------

def strip_html(text):
    """Remove HTML tags and decode HTML entities. Preserve line breaks."""
    if not text:
        return ""
    text = html.unescape(text)
    text = re.sub(r'<br\s*/?>', '\n', text, flags=re.IGNORECASE)
    text = re.sub(r'<[^>]+>', '', text)
    return text.strip()


def try_decode_data_diagram_data(raw):
    """
    Attempt to decode a data-diagram-data attribute value.
    It may be URL-encoded JSON, plain JSON, or base64.
    Returns the inner 'xml' string or None.
    """
    if not raw:
        return None

    # Step 1: unescape HTML entities (&quot; -> ", etc.)
    raw = html.unescape(raw)

    # Step 2: URL-decode if it looks encoded (%XX patterns)
    if '%' in raw:
        try:
            decoded = urllib.parse.unquote_plus(raw)
            if decoded != raw:
                raw = decoded
        except Exception:
            pass

    # Step 3: Try JSON parse
    try:
        data = json.loads(raw)
        if isinstance(data, dict):
            if 'xml' in data:
                return data['xml']
            # Some variants nest under 'diagram'
            if 'diagram' in data and isinstance(data['diagram'], dict) and 'xml' in data['diagram']:
                return data['diagram']['xml']
    except (json.JSONDecodeError, ValueError):
        pass

    # Step 4: If it starts with <mxGraphModel, treat as raw XML
    if '<mxGraphModel' in raw:
        return raw

    return None


def extract_drawio_xml(content):
    """
    Extract draw.io XML from various container formats.
    """
    if not content:
        return None
    content = content.strip()

    # Case 1: Direct mxGraphModel
    if '<mxGraphModel' in content:
        start = content.find('<mxGraphModel')
        end = content.rfind('</mxGraphModel>') + len('</mxGraphModel>')
        if end > start:
            return content[start:end]
        return content[start:]

    # Case 2: data-diagram-data attribute (most common in rendered Confluence HTML)
    # Match either double-quoted or single-quoted, with flexible attribute name
    for pattern in [
        r'data-diagram-data=["\']([^"\']+)["\']',
        r'diagram-data=["\']([^"\']+)["\']',
        r'data-macro-body=["\']([^"\']+)["\']',
    ]:
        matches = re.findall(pattern, content, re.DOTALL | re.IGNORECASE)
        for encoded in matches:
            xml = try_decode_data_diagram_data(encoded)
            if xml:
                return xml

    # Case 3: Confluence storage format with drawio macro body
    macro_pattern = (r'<ac:structured-macro[^>]*drawio[^>]*>.*?'
                     r'<ac:rich-text-body>(.*?)</ac:rich-text-body>.*?</ac:structured-macro>')
    match = re.search(macro_pattern, content, re.DOTALL | re.IGNORECASE)
    if match:
        body = match.group(1)
        return extract_drawio_xml(body)

    # Case 4: Confluence macro with plain-text-body (CDATA)
    cdata_pattern = (r'<ac:structured-macro[^>]*drawio[^>]*>.*?'
                     r'<ac:plain-text-body>.*?<!\[CDATA\[(.*?)\]\]>.*?</ac:plain-text-body>')
    match = re.search(cdata_pattern, content, re.DOTALL | re.IGNORECASE)
    if match:
        return match.group(1).strip()

    # Case 5: <draw-io> tag
    drawio_pattern = r'<draw-io[^>]*>(.*?)</draw-io>'
    match = re.search(drawio_pattern, content, re.DOTALL | re.IGNORECASE)
    if match:
        return match.group(1)

    # Case 6: JSON block with xml field
    try:
        data = json.loads(content)
        if isinstance(data, dict):
            if 'xml' in data:
                return data['xml']
            if 'diagram' in data and isinstance(data['diagram'], dict) and 'xml' in data['diagram']:
                return data['diagram']['xml']
    except (json.JSONDecodeError, ValueError):
        pass

    # Case 7: HTML-entity-encoded mxGraphModel embedded in page text
    if '&lt;mxGraphModel' in content:
        decoded = html.unescape(content)
        if '<mxGraphModel' in decoded:
            return extract_drawio_xml(decoded)

    # Case 8: Look inside <script> tags for diagram JSON
    script_pattern = r'<script[^>]*>.*?(?:diagram|mxGraphModel).*?</script>'
    for script_match in re.finditer(script_pattern, content, re.DOTALL | re.IGNORECASE):
        script_content = script_match.group(0)
        xml = extract_drawio_xml(script_content)
        if xml:
            return xml

    return None


# ---------------------------------------------------------------------------
# Shape / Diagram parsing
# ---------------------------------------------------------------------------

def get_shape_type(style):
    """
    Infer Mermaid node shape from draw.io style string.
    Returns (left_delim, right_delim, shape_name)
    """
    if not style:
        return ('[', ']', 'rect')

    styles = {}
    for part in style.split(';'):
        if '=' in part:
            k, v = part.split('=', 1)
            styles[k.strip()] = v.strip()
        elif part.strip():
            styles[part.strip()] = True

    shape = styles.get('shape', '')
    if not shape:
        for key in styles:
            if key in ('ellipse', 'circle', 'oval', 'rhombus', 'diamond',
                       'parallelogram', 'cylinder', 'hexagon', 'cloud',
                       'rounded', 'start', 'end'):
                shape = key
                break

    if shape in ('ellipse', 'circle', 'oval', 'start', 'end'):
        return ('((', '))', 'circle')
    if shape in ('rhombus', 'diamond'):
        return ('{{', '}}', 'diamond')
    if shape == 'parallelogram':
        return ('[/', ' /]', 'parallelogram')
    if shape in ('cylinder', 'cylinder3'):
        return ('[(', ')]', 'database')
    if shape == 'hexagon':
        return ('{{{{', '}}}}', 'hexagon')
    if styles.get('rounded') or shape == 'rounded':
        return ('(', ')', 'rounded')
    if styles.get('double') or 'doubleEllipse' in shape:
        return ('[[', ']]', 'subroutine')

    return ('[', ']', 'rect')


def sanitize_id(node_id):
    """Create a Mermaid-safe node identifier."""
    if not node_id:
        return 'node'
    safe = re.sub(r'[^a-zA-Z0-9_]', '_', str(node_id))
    if safe and safe[0].isdigit():
        safe = 'N' + safe
    return safe or 'node'


def escape_mermaid_label(text):
    """Escape special characters in Mermaid node/edge labels."""
    if not text:
        return ''
    text = text.replace('"', '#quot;')
    text = text.replace('\n', '<br/>')
    text = text.replace('\r', '')
    return text


class DiagramParser:
    """Parse draw.io mxGraphModel into an intermediate graph representation."""

    def __init__(self, xml_content):
        self.xml_content = xml_content
        self.nodes = {}
        self.edges = []
        self.groups = {}
        self.diagram_type = 'flowchart'
        self._parse()

    def _parse(self):
        try:
            root = ET.fromstring(self.xml_content)
        except ET.ParseError as e:
            try:
                root = ET.fromstring(f'<root>{self.xml_content}</root>')
            except ET.ParseError:
                raise ValueError(f"Invalid XML: {e}")

        graph_model = root if root.tag == 'mxGraphModel' else root.find('.//mxGraphModel')
        if graph_model is None:
            graph_model = root

        mx_cells = graph_model.findall('.//mxCell')

        for cell in mx_cells:
            cell_id = cell.get('id')
            if cell_id in ('0', '1'):
                continue

            value = strip_html(cell.get('value', ''))
            style = cell.get('style', '')
            vertex = cell.get('vertex')
            edge = cell.get('edge')
            parent = cell.get('parent', '1')
            source = cell.get('source')
            target = cell.get('target')

            if 'swimlane' in style:
                self.groups[cell_id] = {
                    'id': cell_id,
                    'value': value or f'Group_{cell_id}',
                    'style': style,
                    'children': []
                }
                continue

            if vertex == '1':
                if 'edgeStyle' in style and not edge:
                    continue
                node = {
                    'id': cell_id,
                    'value': value or cell_id,
                    'style': style,
                    'parent': parent,
                    'shape': get_shape_type(style)
                }
                self.nodes[cell_id] = node
                if parent in self.groups:
                    self.groups[parent]['children'].append(cell_id)

            elif edge == '1' and source and target:
                edge_obj = {
                    'id': cell_id,
                    'source': source,
                    'target': target,
                    'value': value,
                    'style': style
                }
                self.edges.append(edge_obj)

        self._detect_diagram_type()

    def _detect_diagram_type(self):
        swimlane_count = len(self.groups)
        lifeline_count = sum(1 for n in self.nodes.values() if 'lifeline' in n['style'].lower())
        activation_count = sum(1 for n in self.nodes.values() if 'activation' in n['style'].lower())

        if swimlane_count >= 2 or lifeline_count > 0 or activation_count > 0:
            self.diagram_type = 'sequence'
            return

        class_shapes = 0
        for n in self.nodes.values():
            if any(x in n['style'] for x in ('umlClass', 'class;', 'interface;', 'package;')):
                class_shapes += 1
        if class_shapes > 0:
            self.diagram_type = 'class'
            return

        state_shapes = 0
        for n in self.nodes.values():
            if any(x in n['style'] for x in ('state;', 'endState', 'startState')):
                state_shapes += 1
        if state_shapes > 0:
            self.diagram_type = 'state'
            return

        self.diagram_type = 'flowchart'


# ---------------------------------------------------------------------------
# Generators
# ---------------------------------------------------------------------------

def generate_flowchart(parser, direction='TD'):
    """Generate Mermaid flowchart syntax."""
    lines = [f'flowchart {direction}']

    subgraph_ids = set()
    for group_id, group in parser.groups.items():
        if not group['children']:
            continue
        group_label = escape_mermaid_label(group['value'])
        lines.append(f'    subgraph {sanitize_id(group_id)}["{group_label}"]')
        for child_id in group['children']:
            if child_id in parser.nodes:
                node = parser.nodes[child_id]
                sid = sanitize_id(child_id)
                label = escape_mermaid_label(node['value'])
                left, right, _ = node['shape']
                lines.append(f'        {sid}{left}"{label}"{right}')
                subgraph_ids.add(child_id)
        lines.append('    end')

    for node_id, node in parser.nodes.items():
        if node_id in subgraph_ids:
            continue
        sid = sanitize_id(node_id)
        label = escape_mermaid_label(node['value'])
        left, right, _ = node['shape']
        lines.append(f'    {sid}{left}"{label}"{right}')

    for edge in parser.edges:
        src = sanitize_id(edge['source'])
        tgt = sanitize_id(edge['target'])
        label = escape_mermaid_label(edge['value'])

        style = edge.get('style', '')
        if 'dashed=1' in style or 'dashed' in style:
            arrow = '.->'
        elif 'endArrow=none' in style or 'startArrow=none' in style:
            arrow = '--'
        elif 'endArrow=block' in style and 'fill=1' not in style:
            arrow = '-->'
        else:
            arrow = '-->'

        if label:
            lines.append(f'    {src} {arrow}|"{label}"| {tgt}')
        else:
            lines.append(f'    {src} {arrow} {tgt}')

    return '\n'.join(lines)


def generate_sequence_diagram(parser):
    """Generate Mermaid sequenceDiagram syntax from swimlanes/lifelines."""
    lines = ['sequenceDiagram']

    actors = {}
    actor_order = []

    for group_id, group in parser.groups.items():
        actor_name = re.sub(r'[^a-zA-Z0-9_]', '_', group['value']) or f'Actor_{group_id}'
        actors[group_id] = actor_name
        actor_order.append(actor_name)

    if not actors:
        for node_id, node in parser.nodes.items():
            actor_name = re.sub(r'[^a-zA-Z0-9_]', '_', node['value']) or f'Actor_{node_id}'
            if actor_name[0].isdigit():
                actor_name = 'A' + actor_name
            actors[node_id] = actor_name
            actor_order.append(actor_name)

    for name in actor_order:
        lines.append(f'    participant {name}')

    for edge in parser.edges:
        src_id = edge['source']
        tgt_id = edge['target']
        label = escape_mermaid_label(edge['value']) or 'call'

        src_actor = actors.get(src_id)
        tgt_actor = actors.get(tgt_id)

        if src_actor is None:
            for nid, node in parser.nodes.items():
                if nid == src_id:
                    parent = node.get('parent')
                    src_actor = actors.get(parent)
                    break
        if tgt_actor is None:
            for nid, node in parser.nodes.items():
                if nid == tgt_id:
                    parent = node.get('parent')
                    tgt_actor = actors.get(parent)
                    break

        if src_actor and tgt_actor:
            lines.append(f'    {src_actor}->>{tgt_actor}: {label}')
        elif src_actor:
            lines.append(f'    {src_actor}->>+{sanitize_id(tgt_id)}: {label}')
        elif tgt_actor:
            lines.append(f'    {sanitize_id(src_id)}->>{tgt_actor}: {label}')
        else:
            lines.append(f'    {sanitize_id(src_id)}->>{sanitize_id(tgt_id)}: {label}')

    return '\n'.join(lines)


def generate_class_diagram(parser):
    """Basic class diagram generation."""
    lines = ['classDiagram']

    for node_id, node in parser.nodes.items():
        sid = sanitize_id(node_id)
        label = escape_mermaid_label(node['value'])
        lines.append(f'    class {sid}["{label}"]')

    for edge in parser.edges:
        src = sanitize_id(edge['source'])
        tgt = sanitize_id(edge['target'])
        label = escape_mermaid_label(edge['value'])

        style = edge.get('style', '')
        if 'endArrow=block' in style and 'startArrow=diamond' in style:
            relation = '*--'
        elif 'endArrow=block' in style and 'startArrow=none' in style:
            relation = '--|>'
        elif 'endArrow=open' in style:
            relation = '-->'
        else:
            relation = '-->'

        if label:
            lines.append(f'    {src} {relation} {tgt} : {label}')
        else:
            lines.append(f'    {src} {relation} {tgt}')

    return '\n'.join(lines)


def generate_mermaid(parser, direction='TD'):
    """Route to the appropriate generator based on diagram type."""
    if parser.diagram_type == 'sequence':
        return generate_sequence_diagram(parser)
    elif parser.diagram_type == 'class':
        return generate_class_diagram(parser)
    else:
        return generate_flowchart(parser, direction)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def main():
    arg_parser = argparse.ArgumentParser(
        description='Convert draw.io XML (from Confluence or standalone) to Mermaid format'
    )

    # Input sources (mutually exclusive in practice)
    arg_parser.add_argument('input', nargs='?', help='Input file path (.drawio, .xml, .html)')
    arg_parser.add_argument('--url', help='Confluence page URL to fetch')

    # Authentication options
    arg_parser.add_argument('--cookie', help='Browser cookie string for authenticated page access')
    arg_parser.add_argument('--pat', help='Confluence Personal Access Token (Bearer auth)')
    arg_parser.add_argument('--username', help='Username for Basic Auth')
    arg_parser.add_argument('--password', help='Password or API token for Basic Auth')

    # Output / conversion options
    arg_parser.add_argument('-o', '--output', help='Output file path (default: stdout)')
    arg_parser.add_argument('-d', '--direction', default='TD',
                           choices=['TD', 'LR', 'BT', 'RL'],
                           help='Flowchart direction (default: TD)')
    arg_parser.add_argument('-t', '--type', default='auto',
                           choices=['auto', 'flowchart', 'sequence', 'class'],
                           help='Force diagram type (default: auto-detect)')
    arg_parser.add_argument('--api-base', help='Override Confluence REST API base URL')

    args = arg_parser.parse_args()

    # ------------------------------------------------------------------
    # Resolve input content
    # ------------------------------------------------------------------
    content = None
    source_desc = ''

    if args.url:
        source_desc = args.url
        print(f'Fetching: {args.url}', file=sys.stderr)

        # Strategy 1: If cookie is provided, scrape the rendered page HTML directly.
        # This is the most reliable method for Server/DC when REST API returns 498.
        if args.cookie:
            try:
                content = fetch_url(args.url, cookie=args.cookie)
                print('Successfully fetched page HTML using cookie.', file=sys.stderr)
            except RuntimeError as e:
                print(f'Cookie fetch failed: {e}', file=sys.stderr)
                sys.exit(1)

        # Strategy 2: Try REST API with PAT (Bearer) if no cookie or cookie failed.
        elif args.pat or (args.username and args.password):
            page_id = extract_page_id_from_url(args.url)
            api_base = args.api_base or build_api_base_from_url(args.url)

            if page_id:
                api_url = f'{api_base}/content/{page_id}?expand=body.storage'
                print(f'Trying REST API: {api_url}', file=sys.stderr)
                try:
                    if args.pat:
                        content = fetch_url(api_url, pat=args.pat)
                    else:
                        content = fetch_url(api_url, username=args.username, password=args.password)
                    print('Successfully fetched storage format via REST API.', file=sys.stderr)
                except RuntimeError as e:
                    print(f'REST API failed: {e}', file=sys.stderr)
                    print('Hint: For Server/DC 498 errors, use --cookie with your browser session instead.', file=sys.stderr)
                    sys.exit(1)
            else:
                print('Could not extract pageId from URL. Trying direct page fetch with PAT/Basic...', file=sys.stderr)
                try:
                    if args.pat:
                        content = fetch_url(args.url, pat=args.pat)
                    else:
                        content = fetch_url(args.url, username=args.username, password=args.password)
                except RuntimeError as e:
                    print(f'Direct fetch failed: {e}', file=sys.stderr)
                    sys.exit(1)

        # Strategy 3: No auth provided; try public page
        else:
            print('No authentication provided. Trying public access...', file=sys.stderr)
            try:
                content = fetch_url(args.url)
            except RuntimeError as e:
                print(f'Public fetch failed: {e}', file=sys.stderr)
                print('This page requires authentication. Please provide --cookie, --pat, or --username/--password.', file=sys.stderr)
                sys.exit(1)

    elif args.input:
        source_desc = args.input
        with open(args.input, 'r', encoding='utf-8') as f:
            content = f.read()

    else:
        arg_parser.print_help(sys.stderr)
        sys.exit(1)

    # ------------------------------------------------------------------
    # Extract and convert
    # ------------------------------------------------------------------
    drawio_xml = extract_drawio_xml(content)
    if drawio_xml is None:
        print('Error: Could not find draw.io XML content.', file=sys.stderr)
        print('Supported sources: .drawio file, raw mxGraphModel XML, Confluence HTML export, Confluence page URL.', file=sys.stderr)
        sys.exit(1)

    parser = DiagramParser(drawio_xml)
    if args.type != 'auto':
        parser.diagram_type = args.type

    mermaid = generate_mermaid(parser, args.direction)

    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(mermaid)
        print(f'Mermaid diagram written to {args.output}')
    else:
        print(mermaid)


if __name__ == '__main__':
    main()
