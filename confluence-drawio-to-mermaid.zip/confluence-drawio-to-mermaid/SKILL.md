---
name: confluence-drawio-to-mermaid
description: >
  Convert draw.io diagrams (from Confluence pages or standalone .drawio files) to Mermaid markdown syntax.
  Use when Kimi needs to: (1) Transform a Confluence page containing draw.io diagrams into Mermaid format,
  (2) Convert exported Confluence HTML/XML with embedded draw.io charts to Mermaid,
  (3) Migrate draw.io flowcharts, sequence diagrams, or class diagrams into Mermaid for documentation,
  (4) Extract diagram XML from Confluence storage format and render it as Mermaid text.
---

# Confluence draw.io to Mermaid

Convert draw.io XML (embedded in Confluence or standalone) into Mermaid diagram syntax.

## Workflow

### 1. Obtain the draw.io source

**Option A — Direct URL (recommended for Server/DC with 498 errors):**
```bash
# Use browser cookie (most reliable for Server/DC)
python scripts/convert.py --url "https://confluence.company.com/display/SPACE/Page" \
                          --cookie "JSESSIONID=abc123; auth=xyz" \
                          -o output.mmd

# Confluence Cloud with API token
python scripts/convert.py --url "https://company.atlassian.net/wiki/spaces/SPACE/pages/12345" \
                          --username "user@company.com" \
                          --password "api-token" \
                          -o output.mmd
```

**Option B — Confluence HTML export:**
- Export the Confluence page to HTML (or view page source).
- Save the `.html` file.
- `python scripts/convert.py input.html -o output.mmd`

**Option C — Standalone `.drawio`:**
- Download the `.drawio` file from Confluence (Edit in draw.io → File → Save As).
- `python scripts/convert.py input.drawio -o output.mmd`

### 2. Run the converter script

```bash
# Local file
python scripts/convert.py input.html -o output.mmd
python scripts/convert.py input.drawio -o output.mmd

# Remote URL with authentication
python scripts/convert.py --url "PAGE_URL" --cookie "COOKIE_STRING" -o output.mmd
python scripts/convert.py --url "PAGE_URL" --pat "TOKEN" -o output.mmd
python scripts/convert.py --url "PAGE_URL" --username "USER" --password "PASS" -o output.mmd
```

Flags:
- `-d {TD,LR,BT,RL}` — Flowchart direction (default: `TD`).
- `-t {auto,flowchart,sequence,class}` — Force diagram type (default: `auto`).
- `-o FILE` — Write output to file instead of stdout.
- `--api-base` — Override REST API base URL (e.g., `https://host/confluence/rest/api`).

### 3. Validate and refine the output

- Paste the generated Mermaid into a renderer (GitHub, GitLab, Notion, Mermaid Live Editor) to verify.
- Complex layouts, custom shapes, or nested groups may require manual adjustment.
- See [references/drawio-to-mermaid-mapping.md](references/drawio-to-mermaid-mapping.md) for the full shape/edge mapping table, authentication notes, and known limitations.

## What the script handles automatically

- **URL fetching** — Downloads Confluence page HTML or REST API responses with Cookie, PAT, or Basic Auth.
- **Multi-format extraction** — Parses `data-diagram-data` attributes, HTML-entity-encoded XML, CDATA macro bodies, raw `mxGraphModel`, and JSON wrappers.
- **Label sanitization** — Strips HTML tags, decodes entities, converts `<br>` to Mermaid `<br/>`.
- **Diagram type detection** — Identifies flowcharts, sequence diagrams, and class diagrams from swimlanes/lifelines/shape styles.
- **Shape mapping** — Maps draw.io shapes to Mermaid equivalents (ellipse, rhombus, cylinder, etc.).
- **Edge styling** — Preserves edge labels and distinguishes dashed vs solid arrows.
- **Block generation** — Outputs `flowchart`, `sequenceDiagram`, or `classDiagram` blocks.

## What requires manual cleanup

- **State diagrams** — Auto-detected but generated with basic syntax; refine states/transitions manually.
- **Nested subgraphs** — Only one level of swimlane grouping is emitted.
- **Images and icons** — Ignored; replace with text labels or Mermaid-compatible icons.
- **Precise layout** — Mermaid uses automatic layout; relative positions from draw.io are not preserved.
